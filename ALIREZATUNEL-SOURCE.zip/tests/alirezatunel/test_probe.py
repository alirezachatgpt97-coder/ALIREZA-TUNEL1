import asyncio, importlib.util, json, pathlib, socket, tempfile, time, unittest
ROOT=pathlib.Path(__file__).resolve().parents[2]
HELPER=ROOT/'scripts/alirezatunel-probe.py'
ENGINE=pathlib.Path(__import__('os').environ.get('ALIREZATUNEL_BACKPACK_BINARY',str(ROOT/'build/alirezatunel-backpack')))
s=importlib.util.spec_from_file_location('probe',HELPER);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def free():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
class Probe(unittest.IsolatedAsyncioTestCase):
 async def test_native_transport_probes(self):
  if not ENGINE.is_file():self.skipTest("Build the BackPack engine first")
  ENGINE.chmod(0o755)
  for tr in ['stealth','tcpmux','kcp','quic','wsmux','wssmux','udp']:
   with self.subTest(transport=tr),tempfile.TemporaryDirectory() as d:
    port,front,target=free(),free(),free();token='a'*64;processes=[]
    cfg={'front':front,'target':target,'token':token,'seconds':1,'streams':2,'udp':True,'raw_udp':tr=='udp'}
    async def launch(*args):
     p=await asyncio.create_subprocess_exec(*map(str,args),stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE);processes.append(p);return p
    try:
     server=await launch('python3',HELPER,'serve');server.stdin.write((json.dumps(cfg)+'\n').encode());await server.stdin.drain();server.stdin.close()
     self.assertEqual(await asyncio.wait_for(server.stdout.readline(),5),b'READY\n')
     for role in ['server','client']:
      f=pathlib.Path(d)/(role+'.toml')
      f.write_text(f'[{role}]\n'+(f'bind_addr="127.0.0.1:{port}"\nports=["127.0.0.1:{front}=127.0.0.1:{target}"]\n' if role=='server' else f'remote_addr="127.0.0.1:{port}"\n')+f'token="{token}"\ntransport="{tr}"\npreset="balance"\naccept_udp=true\nconnection_pool=2\nmux_session=2\nmux_con=2\nretry_interval=1\n')
      await launch(ENGINE,'-c',f)
     await asyncio.sleep(2)
     r=await asyncio.wait_for(m.measure(cfg),30)
     self.assertGreater(r['download']['bytes'],0);self.assertGreater(r['upload']['bytes'],0)
     self.assertGreater(r['udp']['received'],0)
     print('PASS native',tr,'TCP/UDP' if tr!='udp' else 'UDP',flush=True)
    finally:
     for p in processes:
      if p.returncode is None:
       with __import__('contextlib').suppress(ProcessLookupError):p.kill()
     await asyncio.gather(*(p.wait() for p in processes))
 async def test_untrusted_token_refused(self):
  port=free();c={'token':'a'*64,'target':port}
  p=await asyncio.create_subprocess_exec('python3',HELPER,'serve',stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE)
  p.stdin.write((json.dumps(c)+'\n').encode());await p.stdin.drain();p.stdin.close();await p.stdout.readline()
  try:
   r,w=await asyncio.open_connection('127.0.0.1',port);w.write(b'b'*64+b'D');await w.drain();self.assertEqual(await r.read(1),b'');w.close()
  finally:p.kill();await p.wait()
if __name__=='__main__':unittest.main()
