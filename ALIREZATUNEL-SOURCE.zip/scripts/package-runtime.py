#!/usr/bin/env python3
"""Package only freshly compiled binaries; never silently reuse an old release."""
import argparse, pathlib, hashlib, shutil, tarfile, subprocess, tempfile
p=argparse.ArgumentParser();p.add_argument('--target',required=True);p.add_argument('--arch',choices=['amd64','arm64'],required=True);a=p.parse_args()
root=pathlib.Path(__file__).resolve().parents[1];out=root/'release';out.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory() as d:
 stage=pathlib.Path(d);(stage/'build').mkdir()
 for name in ['kariz','kariz-panel']:
  binary=root/'target'/a.target/'release'/name
  info=subprocess.check_output(['file',str(binary)],text=True)
  assert ('static' in info and ('x86-64' if a.arch=='amd64' else 'aarch64') in info),info
  shutil.copy2(binary,stage/'build'/name)
 shutil.copy2(root/'build/alirezatunel-backpack',stage/'build/alirezatunel-backpack')
 for f in (stage/'build').iterdir():f.chmod(0o755)
 (stage/'build/SHA256SUMS').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name+'\n' for f in sorted((stage/'build').iterdir())))
 for folder in ['scripts','systemd']:
  shutil.copytree(root/folder,stage/folder,ignore=shutil.ignore_patterns('__pycache__'))
 for name in ['install.sh','LICENSE','NOTICE']:shutil.copy2(root/name,stage/name)
 (stage/'licenses').mkdir()
 for n in ['LICENSE','NOTICE']:shutil.copy2(root/'engines/backpack'/n,stage/'licenses'/('BackPack-'+n))
 (stage/'SOURCE.txt').write_text('Complete corresponding source: ALIREZATUNEL-SOURCE.zip in this GitHub release.\n')
 with tarfile.open(out/f'ALIREZATUNEL-linux-{a.arch}.tar.gz','w:gz',compresslevel=9) as t:
  for f in sorted(stage.rglob('*')):
   if f.is_file():t.add(f,arcname=f.relative_to(stage).as_posix())
print(out/f'ALIREZATUNEL-linux-{a.arch}.tar.gz')
