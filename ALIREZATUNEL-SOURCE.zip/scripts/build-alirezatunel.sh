#!/usr/bin/env bash
set -euo pipefail
project_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_root"
for tool in cargo go; do
  command -v "$tool" >/dev/null || { echo "Missing build dependency: $tool" >&2; exit 1; }
done
if [[ -s panel/web/dist/index.html && -s panel/web/dist/source.sha256 ]] && \
    (cd panel/web && sha256sum -c dist/source.sha256 --status); then
  echo 'Using the verified, prebuilt web interface.'
else
  for tool in node npm; do
    command -v "$tool" >/dev/null || { echo "Missing web-build dependency: $tool" >&2; exit 1; }
  done
  npm --prefix panel/web ci --no-audit --no-fund
  npm --prefix panel/web run build
  (
    cd panel/web
    { find src dist -type f ! -path dist/source.sha256 -print0 | LC_ALL=C sort -z | xargs -0 sha256sum;
      sha256sum index.html package.json package-lock.json vite.config.ts tsconfig.json;
    } > dist/source.sha256
  )
fi
jobs="${ALIREZATUNEL_BUILD_JOBS:-}"
if [[ -z $jobs ]]; then
  cpus=$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)
  [[ $cpus =~ ^[1-9][0-9]*$ ]] || cpus=1
  available_kb=$(awk '/MemAvailable:/ {print $2; exit}' /proc/meminfo 2>/dev/null || true)
  [[ $available_kb =~ ^[0-9]+$ ]] || available_kb=1048576
  if [[ -r /sys/fs/cgroup/memory.max && -r /sys/fs/cgroup/memory.current ]]; then
    limit=$(cat /sys/fs/cgroup/memory.max)
    used=$(cat /sys/fs/cgroup/memory.current)
    if [[ $limit =~ ^[0-9]+$ && $used =~ ^[0-9]+$ ]] && (( limit > used )); then
      remaining_kb=$(( (limit - used) / 1024 ))
      (( available_kb <= remaining_kb )) || available_kb=$remaining_kb
    fi
  fi
  jobs=$(( available_kb / 786432 ))
  (( jobs >= 1 )) || jobs=1
  (( jobs <= cpus )) || jobs=$cpus
  (( jobs <= 4 )) || jobs=4
fi
[[ $jobs =~ ^[1-9][0-9]*$ ]] && (( jobs <= 64 )) || { echo 'ALIREZATUNEL_BUILD_JOBS must be 1..64.' >&2; exit 1; }
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-$project_root/target}"
mkdir -p "$CARGO_TARGET_DIR"
CARGO_TARGET_DIR="$(cd "$CARGO_TARGET_DIR" && pwd)"
echo "Building optimized native programs with $jobs parallel job(s); cache: $CARGO_TARGET_DIR"
echo 'The final link can take several minutes without changing the progress counter.'
KARIZ_BUILD_VERSION=2.5.1-alirezatunel.3 cargo build --release --locked --workspace --jobs "$jobs"
mkdir -p build
cp "$CARGO_TARGET_DIR/release/kariz" build/kariz
cp "$CARGO_TARGET_DIR/release/kariz-panel" build/kariz-panel
(
  cd engines/backpack
  GOMAXPROCS="$jobs" go build -p "$jobs" -trimpath -buildvcs=false -o "$project_root/build/alirezatunel-backpack" .
)
cd build
sha256sum kariz kariz-panel alirezatunel-backpack > SHA256SUMS
echo "ALIREZATUNEL built successfully. Run: sudo bash install.sh panel (from the project root)."
