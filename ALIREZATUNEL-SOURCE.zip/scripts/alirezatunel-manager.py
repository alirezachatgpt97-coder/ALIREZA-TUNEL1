#!/usr/bin/env python3
"""Root console for ALIREZATUNEL; no compilation on installed servers."""
import argparse, contextlib, getpass, hashlib, ipaddress, json, os, pathlib, re
import shutil, socket, sqlite3, ssl, subprocess, sys, tempfile, time
ROOT = pathlib.Path('/etc/alirezatunel')
CONF = pathlib.Path('/etc/kariz-panel/panel.toml')
BIN = '/usr/local/bin/kariz-panel'
CERTBOT = pathlib.Path('/opt/alirezatunel-certbot/bin/certbot')
REPO = 'https://raw.githubusercontent.com/alirezachatgpt97-coder/ALIREZA-TUNEL1/main/bootstrap.sh'

def run(args, **kw):
    return subprocess.run([str(x) for x in args], check=True, **kw)

def private(path, text):
    path = pathlib.Path(path); path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temp = tempfile.mkstemp(dir=path.parent)
    try:
        with os.fdopen(fd,'w') as f: f.write(text); f.flush(); os.fsync(f.fileno())
        os.chmod(temp,0o600); os.replace(temp,path)
    finally:
        if os.path.exists(temp): os.unlink(temp)

def fields():
    if not CONF.exists(): return {}
    result = {}
    for line in CONF.read_text().splitlines():
        m = re.fullmatch(r'\s*([a-z_]+)\s*=\s*("(?:[^"\\]|\\.)*")\s*',line)
        if m:
            with contextlib.suppress(ValueError): result[m[1]] = json.loads(m[2])
    return result

def settings():
    return json.loads((ROOT/'setup.json').read_text())

def set_fields(changes):
    text = CONF.read_text()
    for k,v in changes.items():
        line = k+' = '+json.dumps(v,ensure_ascii=False)
        pattern = r'(?m)^\s*'+re.escape(k)+r'\s*=.*$'
        text = re.sub(pattern,lambda _:line,text) if re.search(pattern,text) else text+'\n'+line+'\n'
    private(CONF,text)

def host_name(value):
    value = value.strip().strip('[]')
    try:
        ip = ipaddress.ip_address(value)
    except ValueError:
        if re.fullmatch(r'(?!-)[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+',value) and len(value)<254:
            return value.lower(), False
        raise ValueError('Enter a public IP or a domain without https://, path or port.')
    if not ip.is_global: raise ValueError('A public IP is required.')
    return str(ip), True

def validate_tls(cert,key,host):
    # OpenSSL verify checks the trust chain AND identity, with a non-zero mismatch exit.
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ctx.load_cert_chain(cert,key)
    try: ipaddress.ip_address(host); flag = '-verify_ip'
    except ValueError: flag = '-verify_hostname'
    run(['openssl','x509','-in',cert,'-noout','-checkend','3600'],stdout=subprocess.DEVNULL)
    run(['openssl','verify','-purpose','sslserver',flag,host,'-untrusted',cert,cert],stdout=subprocess.DEVNULL)

def guard():
    c=fields(); s=settings()
    validate_tls(c['cert_file'],c['key_file'],s['host'])

def password_hash():
    c=fields(); db=pathlib.Path(c.get('data_dir','/var/lib/kariz-panel'))/'panel.db'
    with sqlite3.connect(db.as_uri()+'?mode=ro',uri=True) as connection:
        row=connection.execute("SELECT value FROM meta WHERE key='password_hash'").fetchone()
    return row[0] if row else None

def reset_password():
    while True:
        p=getpass.getpass('Panel password (12+ characters): ')
        if len(p)<12 or '\n' in p or '\r' in p: print('Use at least 12 characters.'); continue
        if p != getpass.getpass('Confirm password: '): print('Passwords differ.'); continue
        break
    run([BIN,'reset-password','--stdin'],input=(p+'\n').encode(),stdout=subprocess.DEVNULL)
    private(ROOT/'credentials.json',json.dumps({'password':p,'hash':password_hash()}))
    print('Password updated. Existing sessions were signed out.')

def link():
    s=settings(); c=fields(); h=s['host']; h='['+h+']' if ':' in h else h
    port=c['listen'].rsplit(':',1)[1]
    return 'https://'+h+(':'+port if port!='443' else '')+'/'+c['path']+'/'

def credentials():
    print('Panel URL:',link())
    try:
        saved=json.loads((ROOT/'credentials.json').read_text())
        if saved['hash'] != password_hash(): raise ValueError()
        print('Password:',saved['password'])
    except (OSError,ValueError,KeyError): print('Password changed from the web, or no root copy exists. Run: tun password')

def ensure_certbot():
    if CERTBOT.exists(): return
    run(['apt-get','update'])
    run(['apt-get','install','-y','--no-install-recommends','python3-venv','ca-certificates','openssl'])
    run(['python3','-m','venv',CERTBOT.parent.parent])
    run([CERTBOT.parent/'pip','install','--only-binary=:all:','certbot>=5.4,<6'])

def port_free(port):
    with socket.socket() as sock: sock.bind(('0.0.0.0',port))

def acquire_ssl():
    print('SSL: 1) Domain  2) Public IP  3) Existing trusted certificate')
    choice=input('Choose [1/2/3]: ').strip()
    if choice not in ('1','2','3'): raise ValueError('Choose 1, 2 or 3.')
    host,is_ip=host_name(input('Domain or public IP: '))
    if choice=='1' and is_ip or choice=='2' and not is_ip: raise ValueError('Identity does not match the chosen mode.')
    if choice=='3':
        cert=str(pathlib.Path(input('Full chain PEM path: ').strip()).absolute())
        key=str(pathlib.Path(input('Private key PEM path: ').strip()).absolute())
        managed=False
    else:
        email=input('ACME email: ').strip()
        if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email): raise ValueError('Invalid email.')
        print('Let’s Encrypt terms: https://letsencrypt.org/repository/')
        if input('Agree? Type YES: ').strip()!='YES': raise ValueError('Terms not accepted.')
        method=input('HTTP challenge: standalone or webroot [standalone]: ').strip() or 'standalone'
        args=['--standalone']
        if method=='webroot':
            root=pathlib.Path(input('Webroot directory: ').strip())
            if not root.is_dir(): raise ValueError('Webroot directory does not exist.')
            args=['--webroot','--webroot-path',root]
        elif method=='standalone': port_free(80)
        else: raise ValueError('Unsupported challenge method.')
        print('TCP 80 must be reachable from the internet for issuance and renewal.')
        ensure_certbot()
        certname='alirezatunel-'+hashlib.sha256(host.encode()).hexdigest()[:16]
        cmd=[CERTBOT,'certonly','--non-interactive','--agree-tos','--email',email,'--cert-name',certname]+args
        cmd += ['--ip-address',host,'--preferred-profile','shortlived'] if is_ip else ['-d',host]
        run(cmd)
        cert='/etc/letsencrypt/live/'+certname+'/fullchain.pem'; key='/etc/letsencrypt/live/'+certname+'/privkey.pem'; managed=True
    validate_tls(cert,key,host)
    return {'host':host,'managed':managed}, {'cert_file':cert,'key_file':key}

def renewal(managed):
    if not managed:
        subprocess.run(['systemctl','disable','--now','alirezatunel-cert-renew.timer'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        return
    private('/etc/letsencrypt/renewal-hooks/deploy/alirezatunel', '#!/bin/sh\n/usr/local/bin/tun reload-tls\n')
    os.chmod('/etc/letsencrypt/renewal-hooks/deploy/alirezatunel',0o700)
    pathlib.Path('/etc/systemd/system/alirezatunel-cert-renew.service').write_text('[Unit]\nDescription=ALIREZATUNEL certificate renewal\n[Service]\nType=oneshot\nExecStart='+str(CERTBOT)+' renew --quiet\n')
    pathlib.Path('/etc/systemd/system/alirezatunel-cert-renew.timer').write_text('[Unit]\nDescription=Check certificates twice daily\n[Timer]\nOnCalendar=*-*-* 00,12:00:00\nRandomizedDelaySec=1800\nPersistent=true\n[Install]\nWantedBy=timers.target\n')
    run(['systemctl','daemon-reload']);run(['systemctl','enable','--now','alirezatunel-cert-renew.timer'])

def configure(ssl_only=False):
    if not sys.stdin.isatty(): raise ValueError('Run from an interactive SSH terminal.')
    old=fields()
    if not CONF.exists(): run([BIN,'init'],stdout=subprocess.DEVNULL)
    if not ssl_only and (ROOT/'setup.json').exists():
        try: guard(); ssl_changes={}; s=settings()
        except (OSError,ValueError,KeyError,subprocess.CalledProcessError): s,ssl_changes=acquire_ssl()
    else: s,ssl_changes=acquire_ssl()
    changes=ssl_changes.copy()
    if not ssl_only:
        current=old.get('listen','0.0.0.0:443').rsplit(':',1)[1]
        hp=int(input('HTTPS port ['+current+']: ').strip() or current)
        ap_default=old.get('agent_listen','0.0.0.0:29001').rsplit(':',1)[1]
        ap=int(input('Agent base port ['+ap_default+']: ').strip() or ap_default)
        if not 1<=hp<=65535 or not 1<=ap<=65534 or hp==80 or hp in (ap,ap+1) or 80 in (ap,ap+1): raise ValueError('Ports must be distinct; TCP 80 is reserved for ACME.')
        if str(hp)!=old.get('listen','').rsplit(':',1)[-1]: port_free(hp)
        bind='[::]' if ':' in s['host'] else '0.0.0.0'
        changes.update(listen=f'{bind}:{hp}',agent_listen=f'{bind}:{ap}',release_api='https://api.github.com/repos/alirezachatgpt97-coder/ALIREZA-TUNEL1')
    set_fields(changes);private(ROOT/'setup.json',json.dumps(s));guard()
    if shutil.which('ufw'):
        status=subprocess.run(['ufw','status'],capture_output=True,text=True)
        if re.search(r'^Status: active$',status.stdout,re.M):
            c=fields();hp=c['listen'].rsplit(':',1)[1];ap=int(c['agent_listen'].rsplit(':',1)[1])
            for rule in ['80/tcp',hp+'/tcp']+[str(p)+'/'+proto for p in [ap,ap+1] for proto in ['tcp','udp']]:run(['ufw','allow',rule])
    if not password_hash(): reset_password()
    renewal(s['managed']);run(['systemctl','enable','kariz-panel.service']);run(['systemctl','restart','kariz-panel.service'])
    run(['systemctl','is-active','--quiet','kariz-panel.service'])
    print('Panel configured:',link());print('Management: tun')
    ap=fields()['agent_listen'].rsplit(':',1)[1]
    print('Allow agent TCP/UDP ports '+ap+' and '+str(int(ap)+1)+' in both host/provider firewalls.')

def backup():
    dest=pathlib.Path('/root/alirezatunel-backup-'+time.strftime('%Y%m%d-%H%M%S')+'.tar.gz')
    import tarfile
    with tempfile.TemporaryDirectory() as d:
        db=pathlib.Path(fields().get('data_dir','/var/lib/kariz-panel'))/'panel.db'
        with sqlite3.connect(db) as source,sqlite3.connect(pathlib.Path(d)/'panel.db') as target: source.backup(target)
        with tarfile.open(dest,'w:gz') as t:
            t.add(pathlib.Path(d)/'panel.db',arcname='panel.db')
            for p in ['/etc/kariz','/etc/kariz-panel','/etc/alirezatunel','/etc/letsencrypt']:
                if pathlib.Path(p).exists(): t.add(p,arcname=p.lstrip('/'))
    dest.chmod(0o600);print(dest)

def main(command):
    if os.geteuid()!=0: raise ValueError('Run with sudo/root.')
    ROOT.mkdir(exist_ok=True,mode=0o700);ROOT.chmod(0o700)
    if command=='configure': configure()
    elif command=='ssl': configure(True)
    elif command=='validate-tls': guard()
    elif command=='password': reset_password()
    elif command=='credentials': credentials()
    elif command=='info': print('Panel URL:',link())
    elif command=='backup': backup()
    elif command=='cert-status':
        run(['openssl','x509','-in',fields()['cert_file'],'-noout','-subject','-issuer','-dates']);guard()
    elif command=='renew':
        if not settings()['managed']: raise ValueError('Custom certificate: renew with its provider, then tun reload-tls.')
        run([CERTBOT,'renew']);guard()
    elif command=='reload-tls': guard();run(['systemctl','reload','kariz-panel.service'])
    elif command=='restart': guard();run(['systemctl','restart','kariz-panel.service'])
    elif command=='status': subprocess.run(['systemctl','status','kariz-panel.service','kariz-agent.service','--no-pager'])
    elif command=='logs': run(['journalctl','-u','kariz-panel','-u','kariz-agent','-n','100','--no-pager'])
    elif command=='agent-test':
        run(['systemctl','is-active','kariz-agent.service']);run(['journalctl','-u','kariz-agent','-n','40','--no-pager'])
    elif command=='update':
        mode='panel' if CONF.exists() else 'agent'
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'install.sh';run(['curl','-fL','--retry','3',REPO,'-o',p]);run(['bash',p,mode])
    else: raise ValueError('Unknown command: '+command)

if __name__=='__main__':
    choices=['info','credentials','password','ssl','cert-status','renew','status','logs','restart','reload-tls','agent-test','backup','update','configure']
    if not CONF.exists(): choices=['status','logs','agent-test','update','configure']
    try:
        if len(sys.argv)>1: main(sys.argv[1])
        else:
            while True:
                print('\nALIREZATUNEL — tun')
                for i,c in enumerate(choices,1):print(str(i)+') '+c)
                print('0) Exit');v=input('Choose: ').strip()
                if v=='0':break
                try:
                    if not v.isdigit() or not 1<=int(v)<=len(choices):raise ValueError('Invalid choice.')
                    main(choices[int(v)-1])
                except (ValueError,OSError,KeyError,subprocess.CalledProcessError) as e:print('Error:',e)
    except (ValueError,OSError,KeyError,subprocess.CalledProcessError) as e:print('Error:',e,file=sys.stderr);sys.exit(1)
    except (KeyboardInterrupt,EOFError):sys.exit(130)
