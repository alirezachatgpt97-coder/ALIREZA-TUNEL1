# ALIREZATUNEL

دستورهای نصب تک‌خطی پنل و agent و روش آپلود در گیت‌هاب در [README اصلی](README.md) آمده‌اند.

[راهنمای تنظیمات](docs/ALIREZATUNEL.md)
